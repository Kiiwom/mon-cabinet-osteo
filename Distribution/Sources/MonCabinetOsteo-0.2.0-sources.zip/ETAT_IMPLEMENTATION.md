# État de la première version — 7 septembre 2026

**Mise à jour 0.2.0 :** import initial réalisé — 1 749 patients actifs, 748 fiches archivées, 2 257 consultations, 21 antécédents. Palette du site professionnel appliquée et raccourci Bureau créé. [Bilan et limites de migration](MIGRATION_MCL_2026-09-07.md). Les mentions ci-dessous d’absence d’import décrivent la version 0.1.0. Les tests passent désormais au nombre de 17.

## Disponible

| Parcours | Fonctionnement actuel |
|---|---|
| Patients | Création, modification, recherche par nom/prénom/téléphone/email/ville, accents ignorés. Liste limitée aux 500 premiers résultats ; recherche possible au-delà. |
| Consultation | Date, formulaire, motif, anamnèse, suivi du prochain rendez-vous, enregistrement automatique. |
| Repères patient | Notes importantes et notes/antécédents partagés dans le premier volet et la consultation. |
| Antécédents structurés | Ajout, catégorie, repère temporel, détails, importance ; retrait tracé. |
| Formulaires | Ajout de modèles et de champs texte, texte long, case et liste. Les anciens formulaires sont conservés dans les consultations existantes. |
| Historique | Fil des séances et historique des modifications du dossier, des consultations et des factures. |
| Documents | Pièces jointes conservées dans la base locale, téléchargement, compte-rendu PDF ; maximum 10 Mo par pièce. |
| Facturer | Interrupteur avant émission ; une séance désactivée est exclue des factures à préparer. Suppression d’un brouillon possible. |
| Factures | Brouillon, destinataire indépendant du patient, prestations, tarif, commentaire, émission et PDF. |
| Paiement | Chèque, espèces, CB, ou attente ; règlement du solde en une fois. |
| Correction | Sélection d’un champ ; création transactionnelle de l’avoir et du remplacement, reprise du règlement sans doublon. |
| Numérotation | Format configurable, compteur annuel, premier compteur de démarrage, édition avancée motivée et contrôlée, anciens numéros réservés. |
| Email | Préparation d’un fichier .eml avec PDF joint. Envoi manuel, compatibilité avec la messagerie à valider. |
| Statistiques | Consultations et recettes mensuelles, répartition des moyens de paiement, indicateurs globaux. |
| Export / sauvegarde | Recettes CSV, sauvegarde complète chiffrée, restauration dans un dossier vide par outil local. |
| Présentation | Thème clair/sombre, interface adaptée aux fenêtres étroites. |

## Encore à construire ou approfondir

La reprise MonCabinetLibéral (dossiers, pièces, consultations, rendez-vous, factures et numéros) est un chantier essentiel séparé : aucun import réel n’a été effectué. L’envoi direct des factures, la personnalisation complète des PDF (logo, signature, mentions validées pour le cabinet), l’annulation simple et les remboursements, l’agenda, la fusion/archivage de dossiers, les statistiques détaillées et les fonctions restantes du tri restent à développer. Les paiements partiels, dates/modifications avancées de consultation et l’organisation complète des rubriques ne sont pas disponibles. Les formulaires Adulte, Grossesse et Nourrisson partagent initialement les trois rubriques communes, à personnaliser.

L’autocomplétion d’adresses et Doctolib restent à définir. Les autres services connectés sont exclus conformément aux décisions antérieures. L’interface et le contenu professionnel des documents doivent encore être ajustés avec l’utilisateur à partir d’un essai fictif ; cette version n’est pas présentée comme le remplacement intégral validé de MonCabinetLibéral.

## Vérification réalisée

**11 tests automatisés passent** : notes et conflits d’édition, exclusion des séances non facturées, compteur annuel/mois/reprise, correction et conservation du règlement, émissions concurrentes et paiements répétés, conservation des formulaires historiques, sauvegarde/restauration avec pièces jointes et liens de correction, phrase incorrecte et fichier altéré, PDF, format invalide, renumérotation/doublons/numéros historiques/ordre chronologique, contrat HTTP avec contrôle d’hôte et de session et email avec pièce jointe PDF.

**Parcours vérifiés dans le navigateur intégré**, uniquement avec des données fictives : accueil, ouverture/création de patient, nouvelle consultation, saisie, synchronisation des notes, sauvegarde après rechargement, interrupteur Facturer, brouillon, émission par CB, destinataire parent, correction rapide du nom, comptabilité sans double encaissement, renumérotation refusée puis acceptée, suppression de brouillon, historique, ajout d’un champ personnalisé et disponibilité dans une nouvelle séance, affichage dans un volet de 780 px. PDF d’une page généré et contrôlé visuellement.

Les deux raccourcis ont démarré les serveurs locaux. Le cabinet principal est vide dans AppData ; les essais d’interface ont utilisé exclusivement la base de démonstration. Aucune donnée réelle n’a été copiée de MonCabinetLibéral et aucun email n’a été envoyé.
