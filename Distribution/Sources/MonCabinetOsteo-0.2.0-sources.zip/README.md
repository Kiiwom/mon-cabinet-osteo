# Mon Cabinet d’Ostéo — première version locale

## Distribution et code ouvert

La préparation Windows actuelle est décrite dans [Distribution/README.md](Distribution/README.md) : installateur autonome d’essai, archive source, publications Facebook et procédure GitHub. Elle reste à valider par l’auteur avant diffusion publique. Le code original est sous [licence MIT](LICENSE), avec les [notices des composants tiers](Distribution/Licences/DEPENDANCES.md). Aucun dépôt public ni téléchargement en ligne n’est encore activé pour ce logiciel.

Pour lancer depuis les sources sur un autre ordinateur, sans dépendre de l’environnement de développement de l’auteur :

```powershell
python -m venv .venv
& ./.venv/Scripts/python.exe -m pip install -r requirements.txt
& ./.venv/Scripts/python.exe lancer.py --demo
```

Python 3.12 ou ultérieur est nécessaire pour ce lancement depuis les sources. L’installateur Windows inclut son propre Python. Les notes suivantes décrivent la première version locale ; les vérifications du paquet actuel figurent dans `Distribution/VERIFICATIONS.md`.

Version 0.2.0, mise à jour le 7 septembre 2026. Les patients et notes MonCabinetLibéral sont importés dans le cabinet principal. La reprise comptable complète et les pièces jointes restent à traiter : voir [le bilan de migration](MIGRATION_MCL_2026-09-07.md).

## Ouvrir le logiciel

- Double-cliquer sur **Ouvrir la demonstration.cmd** pour explorer les dossiers fictifs. Adresse : http://127.0.0.1:8766.
- Double-cliquer sur le raccourci **Mon Cabinet d’Ostéo** sur le Bureau, ou sur **Ouvrir mon cabinet.cmd**, pour ouvrir le cabinet avec les patients importés. Adresse : http://127.0.0.1:8765.
- Dans **Paramètres**, renseigner les coordonnées professionnelles, le tarif habituel, les mentions des documents et le compteur de départ avant de préparer les premières factures.

Les raccourcis utilisent le Python déjà présent sur cet ordinateur. Aucune connexion à MonCabinetLibéral, aucun abonnement et aucun hébergement ne sont nécessaires. Fermer l’onglet laisse le petit serveur local actif ; après un redémarrage de Windows, rouvrir le raccourci. Le logiciel ne démarre pas automatiquement avec Windows.

La palette reprend les tons ivoire, brun, beige et or du site professionnel pierre-besnier.fr.

## Le parcours quotidien

1. **Patients → Nouveau patient** : saisir ou coller l’identité et les coordonnées.
2. **Nouvelle consultation** : choisir la date et le formulaire.
3. Remplir **Motif de consultation**, **Anamnèse** et **Notes / antécédents**. Les notes partagées sont également modifiables à côté de l’identité, dans le premier volet. Les notes importantes restent sur la fiche patient.
4. Les modifications sont enregistrées après une courte pause de saisie. L’indicateur affiche l’état de l’enregistrement ; les modifications simultanées dans deux onglets sont détectées.
5. **Facturer** désactivé conserve la séance sans l’ajouter aux factures à préparer. Activé, il permet de préparer un brouillon, adapter le destinataire, puis enregistrer chèque, espèces ou CB et émettre la facture.
6. Télécharger le **PDF**, l’ouvrir pour l’imprimer ou **préparer l’email**. Cette dernière action crée un fichier `.eml` avec le PDF joint, à ouvrir et envoyer soi-même dans une messagerie compatible. La compatibilité de ta messagerie et l’envoi effectif restent à valider.

Le compte-rendu PDF reprend les notes partagées dans leur état actuel, explicitement indiqué sur le document. L’historique conserve les versions antérieures. Les champs personnalisés ajoutés dans Paramètres sont disponibles dans les nouvelles consultations ; les anciennes conservent leur formulaire.

## Factures et corrections

Le format initial est `{AA}-{MM}-{N}`, par exemple `26-09-1744`. Le compteur progresse sur l’année entière ; la première facture de l’année suivante reçoit le compteur **1**. Le premier compteur configurable ne concerne que l’année de démarrage.

**Corriger la facture** propose le nom, le prénom, l’adresse, le code postal, la ville et la civilité. Seul le champ choisi change. L’application crée un avoir et une facture de remplacement, conserve l’original et rattache le règlement une seule fois au remplacement. Les avoirs utilisent actuellement la même séquence annuelle que les factures.

**Paramètres → Numérotation avancée → Éditer un numéro de facture** permet de modifier le numéro d’une facture active. Le format, les doublons et l’ordre chronologique sont contrôlés ; l’ancien numéro reste réservé dans l’historique. L’édition du numéro ne modifie pas les coordonnées ou le montant. Une facture émise maintient Facturer activé ; un brouillon peut être supprimé avant de désactiver cet interrupteur. L’annulation simple et les remboursements restent à construire.

## Données et sauvegarde

- Cabinet : `%LOCALAPPDATA%\MonCabinetOsteo\cabinet.sqlite3`.
- Démonstration : `%LOCALAPPDATA%\MonCabinetOsteoDemo\cabinet.sqlite3`.
- Le code de ce projet reste dans Documents ; les bases, pièces jointes et historiques restent dans AppData, hors de OneDrive.
- Le serveur écoute uniquement sur `127.0.0.1`. Les pages, polices et scripts sont locaux.
- **Paramètres → Sauvegarde chiffrée** produit un fichier `.mco` contenant dossiers, documents, factures, règlements, paramètres et historique. Conserver la phrase de sauvegarde séparément. Le fichier utilise AES-256-GCM et une clé dérivée avec scrypt.
- **Facturation → Exporter les recettes** produit un CSV du registre des règlements. Ce CSV n’est pas une sauvegarde complète.

La restauration est disponible par l’outil `app/restore.py`. Elle exige un dossier local vide ou inexistant, ne remplace jamais un cabinet existant et demande la phrase sans l’afficher. Dans PowerShell, depuis le dossier du projet :

```powershell
$cabinetPython = "$env:USERPROFILE\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
& $cabinetPython app/restore.py 'D:\Sauvegardes\cabinet.mco' "$env:LOCALAPPDATA\MonCabinetOsteoRestaure"
& $cabinetPython app/server.py --data-dir "$env:LOCALAPPDATA\MonCabinetOsteoRestaure" --port 8767
```

Ouvrir ensuite http://127.0.0.1:8767 pour vérifier le cabinet restauré. Fermer ce serveur avec Ctrl+C. La restauration vers une nouvelle base a été testée, y compris les pièces jointes et les liens entre factures corrigées.

## Développement et vérification

Python 3.12+, SQLite, ReportLab et cryptography ; interface HTML/CSS/JavaScript sans dépendance distante. `requirements.txt` décrit les deux dépendances Python. Si le Python fourni avec Codex n’est plus présent, installer ces dépendances dans un Python local puis adapter les raccourcis.

```powershell
& $cabinetPython -m unittest discover -s tests -v
& $cabinetPython app/server.py --demo --data-dir "$env:LOCALAPPDATA\MonCabinetOsteoTest" --port 8768
```

Voir [ETAT_IMPLEMENTATION.md](ETAT_IMPLEMENTATION.md) pour la portée et les vérifications. Les 84 fonctions conservées dans le tri restent le périmètre de travail ; elles ne sont pas toutes implémentées dans cette première version.
