# Publications Facebook

Textes à copier après les essais personnels et l’ouverture des liens. Remplacer `[LIEN_INSTALLATEUR]`, `[LIEN_CODE_SOURCE]` et `[LIEN_SIGNALEMENTS]` d’après `../GitHub/LIENS.md`. Ne pas publier les crochets tels quels.

## 1 — Annoncer le projet pendant les essais

Bonjour à toutes et à tous,

Je prépare un petit geste pour mes collègues ostéopathes : partager gratuitement le logiciel de cabinet que je développe pour mon propre usage, **Mon Cabinet d’Ostéo**.

L’idée est de disposer d’un outil local pour retrouver les dossiers patients, prendre les notes de consultation, préparer les factures et sauvegarder les données.

Je suis encore en phase d’essai. Quand j’aurai terminé mes vérifications, je mettrai à disposition un installateur Windows et le code source sur GitHub.

Le projet sera partagé sous licence MIT : chacun pourra lire le code, le copier, le modifier et le redistribuer en conservant la notice de licence.

Je vous partagerai les liens ici quand tout sera prêt. J’espère que ce travail pourra servir à d’autres cabinets et évoluer grâce aux retours de ceux qui auront envie de l’essayer.

## 2 — Annonce de disponibilité, après validation uniquement

Bonjour les collègues,

Comme promis, je vous partage gratuitement **Mon Cabinet d’Ostéo**, le logiciel que j’ai développé pour mon cabinet.

Il permet de gérer les dossiers patients, les notes de consultation, la préparation des factures et des PDF, le suivi des règlements et les sauvegardes chiffrées. Il fonctionne localement sur un ordinateur Windows 64 bits, avec une interface dans le navigateur, sans abonnement.

Je le mets à disposition sous **licence MIT**. Vous pouvez l’utiliser, consulter son code, en faire une copie, le modifier et le partager à votre tour, en conservant la notice de licence. Le code est ouvert à toutes les personnes qui souhaitent comprendre son fonctionnement ou contribuer.

📥 Installateur Windows et guide : [LIEN_INSTALLATEUR]
🔎 Code source sur GitHub : [LIEN_CODE_SOURCE]
💬 Retours et problèmes techniques : [LIEN_SIGNALEMENTS]

Commencez par la démonstration avec ses dossiers fictifs pour voir si les fonctions proposées correspondent à votre pratique. Le périmètre et les limites de cette version sont décrits dans le dépôt.

Ce partage est ma manière d’apporter quelque chose à notre communauté. Si l’outil vous rend service, vous pouvez transmettre ces liens à vos collègues.

Pour les retours publics, merci d’utiliser uniquement des exemples fictifs, sans nom de patient ni document de cabinet.

## 3 — Rappel court, après mise en ligne

Un outil offert aux collègues ostéopathes 🌿

**Mon Cabinet d’Ostéo** est disponible gratuitement pour Windows : dossiers patients, notes de consultation, facturation et sauvegardes locales.

Le code est ouvert sous licence MIT : vous pouvez le lire, le copier, le modifier et le redistribuer en conservant la licence.

📥 Télécharger : [LIEN_INSTALLATEUR]
🔎 Consulter le code : [LIEN_CODE_SOURCE]

Une démonstration avec des dossiers fictifs permet de découvrir le logiciel. Les fonctions disponibles et les limites sont précisées sur GitHub.
