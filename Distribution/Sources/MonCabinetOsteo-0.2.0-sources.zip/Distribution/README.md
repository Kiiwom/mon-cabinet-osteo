# Distribution — Mon Cabinet d’Ostéo

Préparation du 7 septembre 2026. **Version d’essai 0.2.0, à valider personnellement avant toute diffusion auprès des collègues.** Le numéro est celui du serveur actuel ; le README historique du projet décrit encore la première version.

## Contenu

- `Facebook/PUBLICATIONS.md` : trois textes prêts à adapter, avec emplacements explicites pour les liens.
- `Installateur/MonCabinetOsteo-0.2.0-essai-Setup-x64.exe` : installateur Windows autonome généré et testé, version d’essai.
- `Installateur/GUIDE-INSTALLATION.md` : installation, démonstration, emplacement des données et restauration.
- `Sources/MonCabinetOsteo-0.2.0-sources.zip` : code source sélectionné et scripts de construction, sans base de cabinet ni captures de travail.
- `Licences/LICENSE.txt` : licence MIT applicable au code original du projet.
- `Licences/DROITS-ET-STATUT.md` : explication en français des libertés et du statut des attestations.
- `Licences/Tiers/` et `Licences/DEPENDANCES.md` : notices et inventaire des composants embarqués.
- `GitHub/LIENS.md` : état du dépôt et liens à activer.
- `GitHub/MISE-EN-LIGNE.md` : procédure pour publier le code et les téléchargements après validation.
- `Construction/` : scripts permettant de reconstruire la distribution.
- `VERIFICATIONS.md` : résultats réellement constatés lors de la préparation.
- `SHA256SUMS.txt` : empreintes de l’installateur et de l’archive source.

**Aucune publication Facebook ni mise en ligne GitHub n’est effectuée par cette préparation.** Les textes annonçant la disponibilité sont à utiliser seulement quand le dépôt et les téléchargements sont accessibles et vos essais terminés. Aucun certificat de signature numérique ou de conformité du logiciel n’a été émis.

La licence MIT permet également à un tiers de vendre une copie ou de diffuser une version modifiée sous d’autres conditions, en conservant la notice MIT sur les parties reprises. Elle n’impose pas la publication des modifications. C’est le choix retenu pour accorder les libertés les plus larges demandées.
