# Liens GitHub et téléchargements

**État au 7 septembre 2026 : dépôt de ce logiciel non créé et non relié au projet local. Aucun lien de téléchargement public actif n’est disponible.** Le compte connecté est `Kiiwom`. Aucun dépôt correspondant n’a été trouvé lors de la préparation.

Nom proposé, à confirmer : `mon-cabinet-osteo`.

Les adresses suivantes sont des **adresses prévues, non activées et non vérifiées**. Ne pas les annoncer comme disponibles avant création du dépôt public et publication d’une release.

| Usage | Adresse prévue |
|---|---|
| Code source | `https://github.com/Kiiwom/mon-cabinet-osteo` |
| Page des téléchargements | `https://github.com/Kiiwom/mon-cabinet-osteo/releases` |
| Release d’essai | `https://github.com/Kiiwom/mon-cabinet-osteo/releases/tag/v0.2.0-essai` |
| Installateur direct | `https://github.com/Kiiwom/mon-cabinet-osteo/releases/download/v0.2.0-essai/MonCabinetOsteo-0.2.0-essai-Setup-x64.exe` |
| Archive source | `https://github.com/Kiiwom/mon-cabinet-osteo/releases/download/v0.2.0-essai/MonCabinetOsteo-0.2.0-sources.zip` |
| Signalements | `https://github.com/Kiiwom/mon-cabinet-osteo/issues` |

Pour Facebook, utiliser la page de release comme `[LIEN_INSTALLATEUR]` : elle permet de lire la notice et de sélectionner le bon fichier. Adapter le compte, le nom et la version dans tous les textes si ces choix changent. Une préversion GitHub n’est pas nécessairement la cible de `/releases/latest` ; le lien de release explicite est préférable pour cet essai.
