# Mon Cabinet d’Ostéo 0.2.0 — essai

Logiciel de cabinet local partagé gratuitement sous licence MIT. Cette préparation reste une version d’essai, en attente de validation personnelle par l’auteur.

Fonctions disponibles : dossiers patients, notes et consultations, préparation et émission de factures PDF, règlements, pièces jointes, exports de recettes et sauvegardes chiffrées. Le code comporte un outil d’import initial ; la migration complète et les parcours restants doivent être validés séparément.

Télécharger `MonCabinetOsteo-0.2.0-essai-Setup-x64.exe` pour Windows x64, et commencer par la démonstration. Python est inclus. Consulter `GUIDE-INSTALLATION.md` et les empreintes dans `SHA256SUMS.txt`.

Le code complet de cette distribution est disponible dans le dépôt et dans `MonCabinetOsteo-0.2.0-sources.zip`. La licence permet de lire, copier, modifier et redistribuer ce code, en conservant les notices.

L’installateur est non signé. Cette version ne revendique aucune certification du logiciel. Consulter `ETAT_IMPLEMENTATION.md` pour le périmètre initial et `Distribution/VERIFICATIONS.md` pour les vérifications de ce paquet. Ces documents ne remplacent pas les essais sur votre ordinateur.
