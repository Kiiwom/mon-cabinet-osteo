# Publier après validation des essais

1. Décompresser `Sources/MonCabinetOsteo-0.2.0-sources.zip` dans un dossier distinct. Cette archive contient les fichiers destinés à être partagés ; ne pas publier le dossier de travail complet avec ses captures et inventaires.
2. Vérifier le pseudonyme `Kiiwom` dans `LICENSE`, les contenus originaux et les notices tierces. Examiner les fichiers sources sélectionnés avant leur publication.
3. Créer sur GitHub un dépôt **public** appelé `mon-cabinet-osteo` sur le compte retenu. Le dépôt doit recevoir les fichiers lisibles du code, pas seulement l’archive ZIP. Ne pas générer une seconde licence différente sur GitHub.
4. Depuis le dossier source extrait, avec Git et GitHub CLI installés et authentifiés, les commandes ci-dessous peuvent initialiser et publier le dépôt. Elles sont une procédure manuelle ; elles n’ont pas été exécutées pendant la préparation.

```powershell
git init -b main
git add .
git commit -m "Partager Mon Cabinet d'Osteo sous licence MIT"
gh repo create Kiiwom/mon-cabinet-osteo --public --source . --remote origin --push
```

Si le dépôt a déjà été créé sur le site, ajouter son adresse avec `git remote add origin ...`, puis pousser `main` au lieu de lancer `gh repo create`.

5. Après vos essais, reconstruire la distribution depuis les sources définitives. Créer le tag correspondant exactement à ces sources. Les binaires de cette préparation représentent la version d’essai au moment de leur construction.
6. Créer une release GitHub en **brouillon**, marquée **préversion** pour `v0.2.0-essai`, puis joindre l’installateur `.exe`, l’archive source `.zip`, `SHA256SUMS.txt` et le guide d’installation. Utiliser `NOTES-DE-VERSION.md` comme texte de base. Vérifier les fichiers avant de publier la release.
7. Ouvrir le dépôt et les téléchargements sans connexion pour confirmer leur accès public. Mettre à jour `LIENS.md` et remplacer les emplacements dans `Facebook/PUBLICATIONS.md`.
8. Publier l’annonce Facebook adaptée au niveau de validation réellement atteint. Aucune validation finale personnelle n’est présumée par ce dossier.

Pour contribuer : faire une copie du dépôt (fork), créer une branche, modifier le code, exécuter les tests et proposer une pull request. Utiliser exclusivement des données fictives dans les issues, captures et tests partagés.
