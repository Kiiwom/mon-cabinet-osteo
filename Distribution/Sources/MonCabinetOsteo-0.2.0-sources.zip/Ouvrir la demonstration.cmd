@echo off
setlocal
set "CABINET_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%CABINET_PYTHON%" set "CABINET_PYTHON=python"
"%CABINET_PYTHON%" "%~dp0lancer.py" --demo %*
if errorlevel 1 pause
